class CustomError extends Error {
    constructor(msg) {
        super();
        this.name = "CustomError: ";
        this.message = msg;
    }
};

function throwCustomError() {
    throw new CustomError ("Custom error");
}

function throwGenericError() {
    throw "Generic error";
}

try {
console.log("Generic error try block")
throwGenericError();
}
catch(err){
console.log("Generic error catch block")
console.log("Error:", err)
}
finally {
console.log("Generic error finally block")
}


try {
console.log("Custom error try block")
throwCustomError();
}
catch(err){
console.log("Custom error catch block")
console.log(err.name + err.message)
}
finally {
console.log("Custom error finally block")
}

